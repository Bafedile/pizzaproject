/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.pizzashop.items.extrasinterface;

/**
 *
 * @author benov
 */
public interface ExtrasInterface {
    public final double CHEESE_EXTRAS_AMOUNT = 23.4;
    public final double BACON_EXTRAS_AMOUNT = 25.3;
}
