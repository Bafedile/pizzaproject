/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package za.ac.tut.pizzashop.pizzashopitemsprocessor;

import java.util.List;
import za.ac.tut.pizzashop.items.drinks.Drinks;
import za.ac.tut.pizzashop.items.pizzas.Pizzas;
import za.ac.tut.pizzashop.pizzashopitemsprocessorinterface.PizzaShopItemsProcessorInterface;

/**
 *
 * @author Train 06
 */
public class PizzaShopItemsProcessor implements PizzaShopItemsProcessorInterface{

    @Override
    public void populateThePizzasIntoList(Pizzas pizza, List<Pizzas> pizzas) {
       pizzas.add(pizza);
    }

    @Override
    public String getPizzasFromList(List<Pizzas> pizzas) {
        String pizzaItems = "";
        for(Pizzas pizza: pizzas){
            pizzaItems += pizza.toString();
        }
        return pizzaItems;
    }

    @Override
    public String getDrinksFromList(List<Drinks> drinks) {
       String drinksItems = "";
        for(Drinks drink: drinks){
            drinksItems += drink.toString();
        }
        return drinksItems;
    }

    @Override
    public void populateTheDrinksIntoList(Drinks drink, List<Drinks> drinks) {
       drinks.add(drink);
    }

    @Override
    public String getPizzaFlavours(List<Pizzas> pizzas) {
       String pizzasFlav = "";
        for(Pizzas pizza: pizzas){
            pizzasFlav += pizza.getUnitFlavour();
        }
        return pizzasFlav;
    }

    @Override
    public String getDrinksFlavours(List<Drinks> drinks) {
       String drinksFlav = "";
        for(Drinks drink: drinks){
            drinksFlav += drink.toString();
        }
        return drinksFlav;
    }

    @Override
    public int getPizzaQuantity(List<Pizzas> pizzas) {
       int pizzaQuality = 0;
        for(Pizzas pizza: pizzas){
            pizzaQuality +=pizza.getUnitQuantity();
        }
        return pizzaQuality;
    }

    @Override
    public int getDrinksQuantity(List<Drinks> drinks) {
        int drinksQuality =0;
        for(Drinks drink: drinks){
            drinksQuality += drink.getUnitQuantity();
        }
        return drinksQuality;
    }

    @Override
    public double getTotalDrinksAmount(List<Drinks> drinks) {
       double drinksTot =0;
        for(Drinks drink: drinks){
            drinksTot += drink.determineTotalAmount();
        }
        return drinksTot;
    }

    @Override
    public double getTotalPizzasAmount(List<Pizzas> pizzas) {
        double pizzasTot =0;
        for(Pizzas pizza: pizzas){
            pizzasTot += pizza.determineTotalAmount();
        }
        return pizzasTot;
    }

    @Override
    public double getTotalAmountDue(double totalPizzasAmount, double totalDrinksAmount) {
       double totalAmount = totalPizzasAmount + totalDrinksAmount;
       return totalAmount;
    }
    
}
